<?php
    include_once ("includes/body.inc.php");
    drawTop();
?>

    <!-- dividir por secçoes -> banner home -->
<section class="banner">
    <div class="background_gradient py-5">
        <!-- container-> classe do bootstrap que coloca a informação numa certa largura -->
        <div class="container py-5">
            <div class="row">
                <div class="col-12 col-md-6">
                    <h1 class="pt-5">CONTACTOS</h1>
                    <p>Tem alguma dúvida, questão ou projeto?</p>
                    <p class="text-white"><i class="fas fa-map-marker-alt me-3"></i>Leiria</p>
                    <p class="text-white"><i class="fas fa-phone-alt me-3"></i>919948591</p>
                    <p class="text-white"><i class="fas fa-envelope me-3"></i>sandra_gp_99@hotmail.com</p>
                </div>
                <div class="col-12 col-md-6">
                    <div class="border-shadow p-5 bg-white">
                           <p class="text-center">Preencha o formulário para dar início ao seu projeto</p> 
            
                         <form id="contact" name="contact" action="contact" method="POST">
                  
                        <div class="row mt-3">
                              <div class="col-md-12">
                                  <div class="form-group">
                                        <label for="nome">Nome*</label>
                                      <input type="text" name="nome"  class="form-control" id="nome" value=""/>
                                  </div>
                              </div>
                          </div>

                          <div class="row mt-3">
                              <div class="col-md-12">
                                  <div class="form-group">
                                        <label for="email">Email*</label>
                                      <input type="email" name="email"  class="form-control" id="email" value=""/>
                                  </div>
                              </div>
                          </div>

                          <div class="row mt-3">
                              <div class="col-md-12">
                                  <div class="form-group">
                                        <label for="telefone">Telefone*</label>
                                      <input type="number" name="telefone"  class="form-control" id="telefone" value=""/>
                                  </div>
                              </div>
                          </div>
                       
                          <div class="form-group row mt-4">
                              <div class="col-12 text-center">
                                <button type="submit" class="btn btn-warning">QUERO SABER MAIS</button>
                              
                              </div>
                          </div>
                      </form>

                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<section class="social">

</section>


<?php
    drawBottom();
?>