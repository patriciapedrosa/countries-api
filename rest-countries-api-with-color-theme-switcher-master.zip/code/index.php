<?php
    include_once ("includes/body.inc.php");
    drawTop();

	$countries = allCountries();

?>
<div class="container">
	<div class="row">
	<?php foreach ($countries as $country) { /*var_dump($country);*/ ?>
		<div class="col-md-4">
			<img class="w-100" src="<?php echo $country['flags']['png'] ?>" alt="">
			<h5><?php echo $country['name'] ?></h5>
			<p><b>Population: </b><?php echo $country['population'] ?></p>
			<p><b>Region: </b><?php echo $country['region'] ?></p>
			<?php if(isset($country['capital'])){ ?>
			<p><b>Capital: </b><?php echo $country['capital'] ?></p>
			<?php } ?>
		</div>
	<?php } ?>

	</div>
</div>
<?php
    drawBottom();
?>