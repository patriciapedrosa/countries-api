$(document).ready(function(){

	/* abrir menu */
	$('.hamburger-button').on('click', function(event){
		event.preventDefault();
		$(this).toggleClass('active');
		$('.overlay').toggleClass('visible');
	});

	/*colocar menu a branco quando faço scroll*/
	
	
});